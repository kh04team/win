package admin;

public class order_status_bin {

	private int no;
	private String order_text;
	
	public int getNo() {
		return no;
	}
	public void setNo(int no) {
		this.no = no;
	}
	public String getOrder_text() {
		return order_text;
	}
	public void setOrder_text(String order_text) {
		this.order_text = order_text;
	}
	
	
	
}
