package member;

import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ActionContext;

import com.ibatis.common.resources.Resources;
import com.ibatis.sqlmap.client.SqlMapClient;
import com.ibatis.sqlmap.client.SqlMapClientBuilder;

import java.util.Map;

import java.util.*;
import java.io.Reader;
import java.io.IOException;

import java.net.*;

public class FindIdAction extends ActionSupport {
	public static Reader reader;
	public static SqlMapClient sqlMapper;

	// private member_bin paramClass;

	private member_bin paramClass;
	private member_bin resultClass;

	private String mem_name;
	private String email;
	
	private int cnt;
	
	//private String checkId;


	public FindIdAction() throws IOException {
		reader = Resources.getResourceAsReader("sqlMapConfig.xml");
		sqlMapper = SqlMapClientBuilder.buildSqlMapClient(reader);
		reader.close();
	}

	public String execute() throws Exception {

		paramClass = new member_bin();
		resultClass = new member_bin();

		paramClass.setMem_name(getMem_name());
		paramClass.setEmail(getEmail());

		resultClass = (member_bin) sqlMapper.queryForObject("member.findIdCnt", paramClass);

		if (resultClass.getCnt() > 0) {
			
			paramClass = new member_bin();
			resultClass = new member_bin();

			paramClass.setMem_name(getMem_name());
			paramClass.setEmail(getEmail());		

			resultClass = (member_bin) sqlMapper.queryForObject("member.findId", paramClass);

			return SUCCESS;			
		} else {
			
			return ERROR;
			
		}
	}

	public member_bin getParamClass() {
		return paramClass;
	}

	public void setParamClass(member_bin paramClass) {
		this.paramClass = paramClass;
	}

	public member_bin getResultClass() {
		return resultClass;
	}

	public void setResultClass(member_bin resultClass) {
		this.resultClass = resultClass;
	}

	public String getMem_name() {
		return mem_name;
	}

	public void setMem_name(String mem_name) {
		this.mem_name = mem_name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public int getCnt() {
		return cnt;
	}

	public void setCnt(int cnt) {
		this.cnt = cnt;
	}

	public static Reader getReader() {
		return reader;
	}

	public static void setReader(Reader reader) {
		FindIdAction.reader = reader;
	}

	

}
