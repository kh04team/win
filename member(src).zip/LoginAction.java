package member;

import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ActionContext;

import com.ibatis.common.resources.Resources;
import com.ibatis.sqlmap.client.SqlMapClient;
import com.ibatis.sqlmap.client.SqlMapClientBuilder;

import java.util.Map;

import java.util.*;
import java.io.Reader;
import java.io.IOException;

import java.net.*;

public class LoginAction extends ActionSupport {
	public static Reader reader;
	public static SqlMapClient sqlMapper;

	// private member_bin paramClass;

	private member_bin paramClass;
	private member_bin resultClass;

	private String id;
	private String password;

	private int login_id;

	public int getLogin_id() {
		return login_id;
	}

	public void setLogin_id(int login_id) {
		this.login_id = login_id;
	}

	public LoginAction() throws IOException {
		reader = Resources.getResourceAsReader("sqlMapConfig.xml");
		sqlMapper = SqlMapClientBuilder.buildSqlMapClient(reader);
		reader.close();
	}
	
	public String execute() throws Exception {

		paramClass = new member_bin();
		resultClass = new member_bin();

		paramClass.setId(getId());
		paramClass.setPassword(getPassword());

		
		
		
		resultClass = (member_bin) sqlMapper.queryForObject("member.selectMemCheck", paramClass);

		if (resultClass.getCnt() > 0) {

			ActionContext context = ActionContext.getContext();// session을 생성하기 위해
			Map<String, String> session = (Map<String, String>) context.getSession();// Map 사용시
			session.put("id", getId()); // key, value
			context.setSession(session); // commmit

			return SUCCESS;
		} else {
			return LOGIN;
		}

	}

	public String logout() throws Exception {
		ActionContext context = ActionContext.getContext();
		Map<String, String> session = (Map<String, String>) context.getSession();
	
			session.remove("id");
			
		context.setSession(session);// 다시 session을 적용 시켜서 초기화 시켜야 한다.

		return SUCCESS;
	}

	public member_bin getParamClass() {
		return paramClass;
	}

	public void setParamClass(member_bin paramClass) {
		this.paramClass = paramClass;
	}

	public member_bin getResultClass() {
		return resultClass;
	}

	public void setResultClass(member_bin resultClass) {
		this.resultClass = resultClass;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

}
