package member;

import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ActionContext;

import com.ibatis.common.resources.Resources;
import com.ibatis.sqlmap.client.SqlMapClient;
import com.ibatis.sqlmap.client.SqlMapClientBuilder;

import java.util.Map;

import java.util.*;
import java.io.Reader;
import java.io.IOException;

import java.net.*;

public class FindPwdAction extends ActionSupport {
	public static Reader reader;
	public static SqlMapClient sqlMapper;

	// private member_bin paramClass;

	private member_bin paramClass;
	private member_bin resultClass;

	private String id;
	private String email;
	
	private int cnt;
	
	//private String checkId;


	public FindPwdAction() throws IOException {
		reader = Resources.getResourceAsReader("sqlMapConfig.xml");
		sqlMapper = SqlMapClientBuilder.buildSqlMapClient(reader);
		reader.close();
	}

	public String execute() throws Exception {

		paramClass = new member_bin();
		resultClass = new member_bin();

		paramClass.setId(getId());
		paramClass.setEmail(getEmail());

		resultClass = (member_bin) sqlMapper.queryForObject("member.findPwdCnt", paramClass);

		if (resultClass.getCnt() > 0) {
			
			paramClass = new member_bin();
			resultClass = new member_bin();

			paramClass.setId(getId());
			paramClass.setEmail(getEmail());

			resultClass = (member_bin) sqlMapper.queryForObject("member.findPwd", paramClass);

			return SUCCESS;			
		} else {
			
			return ERROR;
			
		}
	}

	public static Reader getReader() {
		return reader;
	}

	public static void setReader(Reader reader) {
		FindPwdAction.reader = reader;
	}

	public static SqlMapClient getSqlMapper() {
		return sqlMapper;
	}

	public static void setSqlMapper(SqlMapClient sqlMapper) {
		FindPwdAction.sqlMapper = sqlMapper;
	}

	public member_bin getParamClass() {
		return paramClass;
	}

	public void setParamClass(member_bin paramClass) {
		this.paramClass = paramClass;
	}

	public member_bin getResultClass() {
		return resultClass;
	}

	public void setResultClass(member_bin resultClass) {
		this.resultClass = resultClass;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public int getCnt() {
		return cnt;
	}

	public void setCnt(int cnt) {
		this.cnt = cnt;
	}

	

}
