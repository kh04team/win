package member;

import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ActionContext;

import com.ibatis.common.resources.Resources;
import com.ibatis.sqlmap.client.SqlMapClient;
import com.ibatis.sqlmap.client.SqlMapClientBuilder;

import java.util.Map;

import java.util.*;
import java.io.Reader;
import java.io.IOException;

import java.net.*;

public class JoinAction extends ActionSupport {
	public static Reader reader;
	public static SqlMapClient sqlMapper;

	// private member_bin paramClass;
	private member_bin paramClass;
	private member_bin resultClass;

	private String id;
	private String password;
	private String mem_name;
	private String email;
	private String zip_code;
	private String address1;
	private String address2;

	public JoinAction() throws IOException {
		reader = Resources.getResourceAsReader("sqlMapConfig.xml");
		sqlMapper = SqlMapClientBuilder.buildSqlMapClient(reader);
		reader.close();
	}

	public String execute() throws Exception {

		paramClass = new member_bin();
		resultClass = new member_bin();
		
		
		if(resultClass == null) {
			return ERROR;
		}
		paramClass.setId(getId());
		paramClass.setPassword(getPassword());
		paramClass.setMem_name(getMem_name());
		paramClass.setEmail(getEmail());
		paramClass.setZip_code(getZip_code());
		paramClass.setAddress1(getAddress1());
		paramClass.setAddress2(getAddress2());
		paramClass.setMem_grade(10);
		sqlMapper.insert("member.logon", paramClass);
		
		return SUCCESS;
	}

	public static Reader getReader() {
		return reader;
	}

	public static void setReader(Reader reader) {
		JoinAction.reader = reader;
	}

	public static SqlMapClient getSqlMapper() {
		return sqlMapper;
	}

	public static void setSqlMapper(SqlMapClient sqlMapper) {
		JoinAction.sqlMapper = sqlMapper;
	}

	public member_bin getParamClass() {
		return paramClass;
	}

	public void setParamClass(member_bin paramClass) {
		this.paramClass = paramClass;
	}

	public member_bin getResultClass() {
		return resultClass;
	}

	public void setResultClass(member_bin resultClass) {
		this.resultClass = resultClass;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getMem_name() {
		return mem_name;
	}

	public void setMem_name(String mem_name) {
		this.mem_name = mem_name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getZip_code() {
		return zip_code;
	}

	public void setZip_code(String zip_code) {
		this.zip_code = zip_code;
	}

	public String getAddress1() {
		return address1;
	}

	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	public String getAddress2() {
		return address2;
	}

	public void setAddress2(String address2) {
		this.address2 = address2;
	}

}
